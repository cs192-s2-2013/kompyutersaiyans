/**
 * 
 */
/**
 * @author federico
 *
 */
package com.uportal.domain;